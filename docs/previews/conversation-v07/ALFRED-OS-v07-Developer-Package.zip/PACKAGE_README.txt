ALFRED OS v0.7. Read README.md, docs/CONVERSATIONS.md and SESSION_HANDOFF.md.
First-party local development application only. No native OS installation. Small synthetic real-model trial is documented, not general validation.
Upstream quarantine is excluded: full source verifiers require the GitHub branch.
