ALFRED OS v0.8. Read README.md, docs/REVIEWED_MEMORY.md and SESSION_HANDOFF.md.
First-party local development application only. No native OS installation. Reviewed memory and limited evidence checks are implemented. No new model comparison ran in this increment.
Upstream quarantine is excluded: full source verifiers require the GitHub branch.
