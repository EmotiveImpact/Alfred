ALFRED OS v0.6. Read README.md, docs/PERSONAL_OS.md and SESSION_HANDOFF.md.
First-party local development application only. No native OS installation or live-model claim.
Upstream quarantine is excluded: full source verifiers require the GitHub branch.
