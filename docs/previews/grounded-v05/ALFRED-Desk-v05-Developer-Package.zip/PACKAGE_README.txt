ALFRED Desk v0.5 developer package. Original application code and synthetic evidence only.
Not a hosted or installed assistant. Read docs/GROUNDED_DESK.md and README.md.
The eight quarantined upstream snapshots are NOT included; use the GitHub branch for their licences, source archives and verification. No upstream runtime is required for the default Desk.
Run python3 -m unittest discover -s tests -v, then python3 -m alfred.desk init, access, serve using a new private data directory.
No model, microphone or external account is activated by the package.
